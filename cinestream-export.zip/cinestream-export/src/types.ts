export interface Movie {
  id: number;
  title: string;
  description: string;
  genre: string;
  year: number;
  thumbnail_url: string;
  video_url: string;
  rating: number;
  duration: string;
  views: number;
  featured: number;
  created_at: string;
}

export interface User {
  id: number;
  username: string;
  email: string;
  password: string;
  role: 'user' | 'admin';
  avatar_color: string;
  created_at: string;
}

export interface WatchlistItem {
  user_id: number;
  movie_id: number;
}

export interface UserRating {
  user_id: number;
  movie_id: number;
  rating: number;
}

export type AppView = 'auth' | 'user' | 'admin';
export type AuthTab = 'login' | 'register' | 'admin-login';
export type UserPage = 'home' | 'player' | 'genre' | 'watchlist' | 'category';
