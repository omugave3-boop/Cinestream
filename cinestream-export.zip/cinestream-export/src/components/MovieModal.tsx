import React, { useState, useEffect } from 'react';
import { X, Save } from 'lucide-react';
import { Movie } from '../types';
import { GENRES } from '../helpers';

interface MovieModalProps {
  movie: Movie | null;
  onSave: (movie: Omit<Movie, 'id' | 'created_at'>) => void;
  onClose: () => void;
}

export const MovieModal: React.FC<MovieModalProps> = ({ movie, onSave, onClose }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [genre, setGenre] = useState('Action');
  const [year, setYear] = useState(2025);
  const [thumbnailUrl, setThumbnailUrl] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [rating, setRating] = useState(7.0);
  const [duration, setDuration] = useState('');
  const [featured, setFeatured] = useState(false);

  useEffect(() => {
    if (movie) {
      setTitle(movie.title); setDescription(movie.description); setGenre(movie.genre);
      setYear(movie.year); setThumbnailUrl(movie.thumbnail_url); setVideoUrl(movie.video_url);
      setRating(movie.rating); setDuration(movie.duration); setFeatured(movie.featured === 1);
    }
  }, [movie]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({ title, description, genre, year, thumbnail_url: thumbnailUrl, video_url: videoUrl, rating, duration, views: movie?.views || 0, featured: featured ? 1 : 0 });
  };

  return (
    <div className="modal modal-open">
      <div className="modal-box max-w-2xl bg-base-200">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold">{movie ? 'Edit Movie' : 'Add New Movie'}</h3>
          <button className="btn btn-ghost btn-sm btn-circle" onClick={onClose}><X size={18} /></button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="label"><span className="label-text font-medium">Title *</span></label>
              <input className="input input-bordered w-full" value={title} onChange={(e) => setTitle(e.target.value)} required placeholder="Movie title" />
            </div>
            <div>
              <label className="label"><span className="label-text font-medium">Genre *</span></label>
              <select className="select select-bordered w-full" value={genre} onChange={(e) => setGenre(e.target.value)}>
                {GENRES.map((g) => <option key={g} value={g}>{g}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="label"><span className="label-text font-medium">Description</span></label>
            <textarea className="textarea textarea-bordered w-full h-24" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Movie description..." />
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            <div>
              <label className="label"><span className="label-text font-medium">Year</span></label>
              <input type="number" className="input input-bordered w-full" value={year} onChange={(e) => setYear(Number(e.target.value))} min={1900} max={2030} />
            </div>
            <div>
              <label className="label"><span className="label-text font-medium">Rating</span></label>
              <input type="number" className="input input-bordered w-full" value={rating} onChange={(e) => setRating(Number(e.target.value))} min={0} max={10} step={0.1} />
            </div>
            <div>
              <label className="label"><span className="label-text font-medium">Duration</span></label>
              <input className="input input-bordered w-full" value={duration} onChange={(e) => setDuration(e.target.value)} placeholder="2h 15m" />
            </div>
          </div>
          <div>
            <label className="label"><span className="label-text font-medium">Thumbnail URL *</span></label>
            <input className="input input-bordered w-full" value={thumbnailUrl} onChange={(e) => setThumbnailUrl(e.target.value)} required placeholder="https://example.com/poster.jpg" />
          </div>
          <div>
            <label className="label"><span className="label-text font-medium">Video URL *</span></label>
            <input className="input input-bordered w-full" value={videoUrl} onChange={(e) => setVideoUrl(e.target.value)} required placeholder="https://example.com/movie.mp4" />
          </div>
          <div className="flex items-center gap-2">
            <input type="checkbox" className="toggle toggle-primary" checked={featured} onChange={(e) => setFeatured(e.target.checked)} />
            <span className="label-text">Featured movie</span>
          </div>
          <div className="modal-action">
            <button type="button" className="btn btn-ghost" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn btn-primary"><Save size={16} /> {movie ? 'Update Movie' : 'Add Movie'}</button>
          </div>
        </form>
      </div>
      <div className="modal-backdrop" onClick={onClose}></div>
    </div>
  );
};
