import React from 'react';
import { Film, Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-base-200 border-t border-base-content/10 mt-12">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Film className="text-primary" size={22} />
              <span className="text-lg font-bold">Cine<span className="text-primary">Stream</span></span>
            </div>
            <p className="text-sm text-base-content/50">
              Your premium destination for streaming the latest and greatest movies.
            </p>
          </div>
          <div>
            <h4 className="font-semibold text-sm mb-3">Browse</h4>
            <ul className="space-y-1 text-sm text-base-content/50">
              <li>Trending Movies</li>
              <li>Top Rated</li>
              <li>New Releases</li>
              <li>All Genres</li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-sm mb-3">Support</h4>
            <ul className="space-y-1 text-sm text-base-content/50">
              <li>Help Center</li>
              <li>Contact Us</li>
              <li>Privacy Policy</li>
              <li>Terms of Service</li>
            </ul>
          </div>
        </div>
        <div className="border-t border-base-content/10 mt-6 pt-6 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p className="text-xs text-base-content/40">&copy; 2026 CineStream. All rights reserved.</p>
          <p className="text-xs text-base-content/40 flex items-center gap-1">
            Made with <Heart size={10} className="text-error" /> for movie lovers
          </p>
        </div>
      </div>
    </footer>
  );
};
