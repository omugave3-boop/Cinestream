import React, { useState } from 'react';
import { Film, LogIn, UserPlus, Shield, Eye, EyeOff, Mail, Lock, User as UserIcon } from 'lucide-react';
import { AuthTab, User } from '../types';
import { getRandomColor } from '../helpers';
import { findUser, findUserByEmailOrUsername, registerUser } from '../store';

interface AuthScreenProps {
  onLogin: (user: User) => void;
  onAdminLogin: (user: User) => void;
  initialTab?: AuthTab;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({ onLogin, onAdminLogin, initialTab = 'login' }) => {
  const [tab, setTab] = useState<AuthTab>(initialTab);
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const resetForm = () => {
    setUsername(''); setEmail(''); setPassword(''); setError(''); setShowPassword(false);
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!username.trim() || !email.trim() || !password.trim()) { setError('All fields are required'); return; }
    if (password.length < 4) { setError('Password must be at least 4 characters'); return; }
    setLoading(true);
    try {
      const existing = findUserByEmailOrUsername(email, username);
      if (existing) { setError('Username or email already exists'); setLoading(false); return; }
      const color = getRandomColor();
      const user = registerUser(username, email, password, color);
      onLogin(user);
    } catch { setError('Registration failed. Please try again.'); }
    finally { setLoading(false); }
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!email.trim() || !password.trim()) { setError('Email and password are required'); return; }
    setLoading(true);
    try {
      const user = findUser(email, password, 'user');
      if (!user) { setError('Invalid email or password'); setLoading(false); return; }
      onLogin(user);
    } catch { setError('Login failed. Please try again.'); }
    finally { setLoading(false); }
  };

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!email.trim() || !password.trim()) { setError('Email and password are required'); return; }
    setLoading(true);
    try {
      const user = findUser(email, password, 'admin');
      if (!user) { setError('Invalid admin credentials'); setLoading(false); return; }
      onAdminLogin(user);
    } catch { setError('Login failed. Please try again.'); }
    finally { setLoading(false); }
  };

  return (
    <div className="min-h-screen bg-base-100 flex flex-col">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-secondary/5 rounded-full blur-3xl" />
      </div>
      <div className="flex-1 flex items-center justify-center p-4 relative z-10">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <div className="flex items-center justify-center gap-3 mb-3">
              <Film className="text-primary" size={40} />
              <span className="text-3xl font-bold tracking-tight">Cine<span className="text-primary">Stream</span></span>
            </div>
            <p className="text-base-content/50 text-sm">Your premium movie streaming platform</p>
          </div>
          <div className="card bg-base-200 shadow-xl">
            <div className="card-body p-6">
              <div className="tabs tabs-boxed bg-base-300 mb-6">
                <button className={`tab flex-1 gap-1 ${tab === 'login' ? 'tab-active' : ''}`} onClick={() => { setTab('login'); resetForm(); }}>
                  <LogIn size={14} /> Login
                </button>
                <button className={`tab flex-1 gap-1 ${tab === 'register' ? 'tab-active' : ''}`} onClick={() => { setTab('register'); resetForm(); }}>
                  <UserPlus size={14} /> Register
                </button>
                <button className={`tab flex-1 gap-1 ${tab === 'admin-login' ? 'tab-active' : ''}`} onClick={() => { setTab('admin-login'); resetForm(); }}>
                  <Shield size={14} /> Admin
                </button>
              </div>
              {error && <div className="alert alert-error text-sm py-2 mb-4"><span>{error}</span></div>}

              {tab === 'login' && (
                <form onSubmit={handleLogin} className="space-y-4">
                  <div><label className="input input-bordered flex items-center gap-2"><Mail className="h-[1em] opacity-50" /><input type="email" className="grow" placeholder="Email address" value={email} onChange={(e) => setEmail(e.target.value)} required /></label></div>
                  <div><label className="input input-bordered flex items-center gap-2"><Lock className="h-[1em] opacity-50" /><input type={showPassword ? 'text' : 'password'} className="grow" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} required /><button type="button" onClick={() => setShowPassword(!showPassword)} className="opacity-50 hover:opacity-100">{showPassword ? <EyeOff size={16} /> : <Eye size={16} />}</button></label></div>
                  <button className="btn btn-primary w-full" disabled={loading}>{loading ? <span className="loading loading-spinner loading-sm" /> : <><LogIn size={16} /> Sign In</>}</button>
                  <p className="text-center text-sm text-base-content/50">Don&apos;t have an account?{' '}<button type="button" className="text-primary hover:underline" onClick={() => { setTab('register'); resetForm(); }}>Register here</button></p>
                </form>
              )}
              {tab === 'register' && (
                <form onSubmit={handleRegister} className="space-y-4">
                  <div><label className="input input-bordered flex items-center gap-2"><UserIcon className="h-[1em] opacity-50" /><input type="text" className="grow" placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} required /></label></div>
                  <div><label className="input input-bordered flex items-center gap-2"><Mail className="h-[1em] opacity-50" /><input type="email" className="grow" placeholder="Email address" value={email} onChange={(e) => setEmail(e.target.value)} required /></label></div>
                  <div><label className="input input-bordered flex items-center gap-2"><Lock className="h-[1em] opacity-50" /><input type={showPassword ? 'text' : 'password'} className="grow" placeholder="Password (min 4 chars)" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={4} /><button type="button" onClick={() => setShowPassword(!showPassword)} className="opacity-50 hover:opacity-100">{showPassword ? <EyeOff size={16} /> : <Eye size={16} />}</button></label></div>
                  <button className="btn btn-primary w-full" disabled={loading}>{loading ? <span className="loading loading-spinner loading-sm" /> : <><UserPlus size={16} /> Create Account</>}</button>
                  <p className="text-center text-sm text-base-content/50">Already have an account?{' '}<button type="button" className="text-primary hover:underline" onClick={() => { setTab('login'); resetForm(); }}>Sign in</button></p>
                </form>
              )}
              {tab === 'admin-login' && (
                <form onSubmit={handleAdminLogin} className="space-y-4">
                  <div className="alert alert-info text-sm py-2 mb-2"><Shield size={14} /><span>Default: admin@cinestream.com / admin123</span></div>
                  <div><label className="input input-bordered flex items-center gap-2"><Mail className="h-[1em] opacity-50" /><input type="email" className="grow" placeholder="Admin email" value={email} onChange={(e) => setEmail(e.target.value)} required /></label></div>
                  <div><label className="input input-bordered flex items-center gap-2"><Lock className="h-[1em] opacity-50" /><input type={showPassword ? 'text' : 'password'} className="grow" placeholder="Admin password" value={password} onChange={(e) => setPassword(e.target.value)} required /><button type="button" onClick={() => setShowPassword(!showPassword)} className="opacity-50 hover:opacity-100">{showPassword ? <EyeOff size={16} /> : <Eye size={16} />}</button></label></div>
                  <button className="btn btn-secondary w-full" disabled={loading}>{loading ? <span className="loading loading-spinner loading-sm" /> : <><Shield size={16} /> Admin Login</>}</button>
                </form>
              )}
            </div>
          </div>
          <p className="text-center text-xs text-base-content/30 mt-6">&copy; 2026 CineStream. All rights reserved.</p>
        </div>
      </div>
    </div>
  );
};
