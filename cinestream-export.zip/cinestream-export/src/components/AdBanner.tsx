import React from 'react';
import { Megaphone } from 'lucide-react';

interface AdBannerProps {
  size?: 'banner' | 'sidebar' | 'leaderboard';
}

export const AdBanner: React.FC<AdBannerProps> = ({ size = 'banner' }) => {
  const sizeClasses: Record<string, string> = {
    banner: 'h-24 w-full',
    sidebar: 'h-64 w-full',
    leaderboard: 'h-16 w-full',
  };

  // To use real Google AdSense ads, replace the content below with your AdSense ad unit code:
  // <ins className="adsbygoogle" style={{display:"block"}} data-ad-client="ca-pub-XXXXXXXX" data-ad-slot="XXXXXXXX" data-ad-format="auto" data-full-width-responsive="true"></ins>
  // and call (window.adsbygoogle = window.adsbygoogle || []).push({}) in a useEffect.

  return (
    <div
      className={`${sizeClasses[size]} rounded-lg border border-dashed border-base-content/20 bg-base-200/50 flex items-center justify-center gap-2 text-base-content/30 text-sm my-4`}
    >
      <Megaphone size={16} className="opacity-60" />
      <span>Google Ad Space — {size === 'leaderboard' ? '728×90' : size === 'sidebar' ? '300×250' : '468×60'}</span>
    </div>
  );
};
