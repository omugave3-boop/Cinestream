import React, { useState } from 'react';
import { Plus, Edit3, Trash2, Eye, Star, Film, Search, TrendingUp, Users, BarChart3 } from 'lucide-react';
import { Movie, User } from '../types';
import { MovieModal } from './MovieModal';
import { formatViews } from '../helpers';
import { addMovie, updateMovie, deleteMovie, getUserCount } from '../store';

interface AdminPanelProps {
  movies: Movie[];
  onRefresh: () => void;
  currentUser: User | null;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ movies, onRefresh, currentUser }) => {
  const [showModal, setShowModal] = useState(false);
  const [editMovie, setEditMovie] = useState<Movie | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null);

  const totalUsers = getUserCount();

  const filteredMovies = movies.filter((m) =>
    m.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    m.genre.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalViews = movies.reduce((sum, m) => sum + m.views, 0);
  const avgRating = movies.length ? (movies.reduce((sum, m) => sum + m.rating, 0) / movies.length).toFixed(1) : '0';
  const topMovie = movies.length ? [...movies].sort((a, b) => b.views - a.views)[0] : null;

  const handleSave = (movieData: Omit<Movie, 'id' | 'created_at'>) => {
    if (editMovie) {
      updateMovie(editMovie.id, movieData);
    } else {
      addMovie(movieData);
    }
    setShowModal(false);
    setEditMovie(null);
    onRefresh();
  };

  const handleDelete = (id: number) => {
    deleteMovie(id);
    setDeleteConfirm(null);
    onRefresh();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <div className="mb-6">
        <h2 className="text-xl font-bold">Admin Dashboard</h2>
        <p className="text-sm text-base-content/50">Welcome back, {currentUser?.username || 'Admin'}</p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
        <div className="card bg-base-200"><div className="card-body p-4"><div className="flex items-center gap-2 text-base-content/60 text-xs"><Film size={14} className="opacity-60" /> Movies</div><p className="text-2xl font-bold">{movies.length}</p></div></div>
        <div className="card bg-base-200"><div className="card-body p-4"><div className="flex items-center gap-2 text-base-content/60 text-xs"><Eye size={14} className="opacity-60" /> Views</div><p className="text-2xl font-bold">{formatViews(totalViews)}</p></div></div>
        <div className="card bg-base-200"><div className="card-body p-4"><div className="flex items-center gap-2 text-base-content/60 text-xs"><Star size={14} className="opacity-60" /> Avg Rating</div><p className="text-2xl font-bold">{avgRating}</p></div></div>
        <div className="card bg-base-200"><div className="card-body p-4"><div className="flex items-center gap-2 text-base-content/60 text-xs"><Users size={14} className="opacity-60" /> Users</div><p className="text-2xl font-bold">{totalUsers}</p></div></div>
        <div className="card bg-base-200"><div className="card-body p-4"><div className="flex items-center gap-2 text-base-content/60 text-xs"><TrendingUp size={14} className="opacity-60" /> Featured</div><p className="text-2xl font-bold">{movies.filter((m) => m.featured === 1).length}</p></div></div>
        <div className="card bg-base-200"><div className="card-body p-4"><div className="flex items-center gap-2 text-base-content/60 text-xs"><BarChart3 size={14} className="opacity-60" /> Top Movie</div><p className="text-sm font-bold truncate" title={topMovie?.title}>{topMovie?.title || '—'}</p></div></div>
      </div>

      <div className="card bg-base-200 mb-6 p-4">
        <h3 className="text-sm font-semibold mb-3">Movies by Genre</h3>
        <div className="flex flex-wrap gap-2">
          {Array.from(new Set(movies.map(m => m.genre))).map(genre => {
            const count = movies.filter(m => m.genre === genre).length;
            return <div key={genre} className="badge badge-lg gap-1 bg-base-300 border-0">{genre} <span className="font-bold">{count}</span></div>;
          })}
        </div>
      </div>

      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-4">
        <label className="input input-bordered input-sm flex items-center gap-2 bg-base-200 border-base-content/10 flex-1 max-w-sm">
          <Search className="h-[1em] opacity-50" />
          <input type="search" className="grow" placeholder="Search movies..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
        </label>
        <button className="btn btn-primary btn-sm" onClick={() => { setEditMovie(null); setShowModal(true); }}><Plus size={16} /> Add Movie</button>
      </div>

      <div className="card bg-base-200 overflow-x-auto">
        <table className="table table-sm">
          <thead>
            <tr>
              <th>Movie</th>
              <th className="hidden sm:table-cell">Genre</th>
              <th className="hidden sm:table-cell">Year</th>
              <th className="hidden md:table-cell">Rating</th>
              <th className="hidden md:table-cell">Views</th>
              <th className="hidden lg:table-cell">Featured</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredMovies.length === 0 ? (
              <tr><td colSpan={7} className="text-center py-8 text-base-content/50">{searchQuery ? 'No movies match your search' : 'No movies yet. Add your first movie!'}</td></tr>
            ) : (
              filteredMovies.map((movie) => (
                <tr key={movie.id} className="hover">
                  <td>
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-14 rounded-md overflow-hidden shrink-0 bg-base-300">
                        <img src={movie.thumbnail_url} alt={movie.title} className="w-full h-full object-cover" />
                      </div>
                      <div>
                        <div className="font-semibold text-sm">{movie.title}</div>
                        <div className="text-xs text-base-content/50 sm:hidden">{movie.genre} · {movie.year}</div>
                      </div>
                    </div>
                  </td>
                  <td className="hidden sm:table-cell"><span className="badge badge-sm bg-base-300 border-0">{movie.genre}</span></td>
                  <td className="hidden sm:table-cell text-sm">{movie.year}</td>
                  <td className="hidden md:table-cell"><span className="flex items-center gap-1 text-sm"><Star size={12} className="text-warning" /> {movie.rating}</span></td>
                  <td className="hidden md:table-cell text-sm">{formatViews(movie.views)}</td>
                  <td className="hidden lg:table-cell">{movie.featured === 1 && <span className="badge badge-primary badge-sm">Yes</span>}</td>
                  <td>
                    <div className="flex items-center gap-1">
                      <button className="btn btn-ghost btn-xs" onClick={() => { setEditMovie(movie); setShowModal(true); }}><Edit3 size={14} /></button>
                      {deleteConfirm === movie.id ? (
                        <div className="flex items-center gap-1">
                          <button className="btn btn-error btn-xs" onClick={() => handleDelete(movie.id)}>Yes</button>
                          <button className="btn btn-ghost btn-xs" onClick={() => setDeleteConfirm(null)}>No</button>
                        </div>
                      ) : (
                        <button className="btn btn-ghost btn-xs text-error" onClick={() => setDeleteConfirm(movie.id)}><Trash2 size={14} /></button>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {showModal && <MovieModal movie={editMovie} onSave={handleSave} onClose={() => { setShowModal(false); setEditMovie(null); }} />}
    </div>
  );
};
