import React from 'react';
import { Star, Eye, Play, Bookmark, BookmarkCheck } from 'lucide-react';
import { Movie } from '../types';
import { formatViews } from '../helpers';

interface MovieCardProps {
  movie: Movie;
  onPlay: (movie: Movie) => void;
  variant?: 'default' | 'featured';
  inWatchlist?: boolean;
  onToggleWatchlist?: (movieId: number) => void;
}

export const MovieCard: React.FC<MovieCardProps> = ({ movie, onPlay, variant = 'default', inWatchlist, onToggleWatchlist }) => {
  if (variant === 'featured') {
    return (
      <div className="relative h-72 sm:h-96 rounded-2xl overflow-hidden cursor-pointer group" onClick={() => onPlay(movie)}>
        <img src={movie.thumbnail_url} alt={movie.title} className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
        <div className="absolute inset-0 bg-gradient-to-t from-base-100 via-base-100/40 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-6 sm:p-8">
          <div className="flex items-center gap-2 mb-2">
            <span className="badge badge-primary badge-sm">Featured</span>
            <span className="badge badge-sm bg-base-300/80 border-0">{movie.genre}</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-bold mb-2">{movie.title}</h2>
          <p className="text-base-content/70 text-sm sm:text-base line-clamp-2 max-w-2xl mb-4">{movie.description}</p>
          <div className="flex items-center gap-3">
            <button className="btn btn-primary"><Play size={18} /> Watch Now</button>
            {onToggleWatchlist && (
              <button className="btn btn-ghost btn-circle" onClick={(e) => { e.stopPropagation(); onToggleWatchlist(movie.id); }}>
                {inWatchlist ? <BookmarkCheck size={20} className="text-primary" /> : <Bookmark size={20} />}
              </button>
            )}
            <div className="flex items-center gap-3 text-sm text-base-content/60">
              <span className="flex items-center gap-1"><Star size={14} className="text-warning" /> {movie.rating}</span>
              <span className="flex items-center gap-1"><Eye size={14} className="opacity-60" /> {formatViews(movie.views)}</span>
              <span>{movie.year}</span>
              <span>{movie.duration}</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="group cursor-pointer" onClick={() => onPlay(movie)}>
      <div className="relative aspect-[2/3] rounded-xl overflow-hidden mb-2">
        <img src={movie.thumbnail_url} alt={movie.title} className="absolute inset-0 w-full h-full object-cover transition-transform duration-300 group-hover:scale-110" />
        <div className="absolute inset-0 bg-base-100/0 group-hover:bg-base-100/40 transition-colors flex items-center justify-center">
          <div className="btn btn-circle btn-primary opacity-0 group-hover:opacity-100 transition-opacity"><Play size={20} /></div>
        </div>
        <div className="absolute top-2 right-2 flex gap-1">
          {onToggleWatchlist && (
            <button className="btn btn-circle btn-xs bg-base-300/80 border-0 hover:bg-primary hover:text-primary-content" onClick={(e) => { e.stopPropagation(); onToggleWatchlist(movie.id); }}>
              {inWatchlist ? <BookmarkCheck size={12} className="text-primary" /> : <Bookmark size={12} />}
            </button>
          )}
        </div>
        <div className="absolute top-2 left-2">
          <span className="badge badge-sm bg-base-300/80 text-base-content border-0">{movie.duration}</span>
        </div>
      </div>
      <h3 className="font-semibold text-sm truncate">{movie.title}</h3>
      <div className="flex items-center gap-2 text-xs text-base-content/60 mt-0.5">
        <span className="flex items-center gap-0.5"><Star size={11} className="text-warning" /> {movie.rating}</span>
        <span>{movie.year}</span>
        <span>{movie.genre}</span>
      </div>
    </div>
  );
};
