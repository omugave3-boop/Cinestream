import React, { useState, useEffect } from 'react';
import { Sparkles, Bookmark, Film } from 'lucide-react';
import { Movie, User } from '../types';
import { MovieCard } from './MovieCard';
import { MoviePlayer } from './MoviePlayer';
import { AdBanner } from './AdBanner';
import { Footer } from './Footer';
import { GENRES, COLLECTIONS } from '../helpers';
import { getUserWatchlist, addToWatchlist, removeFromWatchlist, incrementViews } from '../store';

interface UserViewProps {
  movies: Movie[];
  searchQuery: string;
  currentUser: User | null;
  showWatchlist: boolean;
  onClearWatchlist: () => void;
  onMoviesChange: () => void;
}

export const UserView: React.FC<UserViewProps> = ({ movies, searchQuery, currentUser, showWatchlist, onClearWatchlist, onMoviesChange }) => {
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);
  const [selectedGenre, setSelectedGenre] = useState<string>('');
  const [watchlistIds, setWatchlistIds] = useState<Set<number>>(new Set());

  useEffect(() => {
    if (currentUser) {
      const ids = getUserWatchlist(currentUser.id);
      setWatchlistIds(new Set(ids));
    }
  }, [currentUser]);

  const toggleWatchlist = (movieId: number) => {
    if (!currentUser) return;
    const newIds = new Set(watchlistIds);
    if (newIds.has(movieId)) {
      newIds.delete(movieId);
      removeFromWatchlist(currentUser.id, movieId);
    } else {
      newIds.add(movieId);
      addToWatchlist(currentUser.id, movieId);
    }
    setWatchlistIds(newIds);
  };

  const filteredMovies = movies.filter((m) => {
    const matchesSearch = !searchQuery ||
      m.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.genre.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesGenre = !selectedGenre || m.genre === selectedGenre;
    return matchesSearch && matchesGenre;
  });

  const featuredMovies = movies.filter((m) => m.featured === 1);
  const watchlistMovies = movies.filter(m => watchlistIds.has(m.id));

  const handlePlay = (movie: Movie) => {
    setSelectedMovie(movie);
    onClearWatchlist();
    incrementViews(movie.id);
    onMoviesChange();
  };

  if (selectedMovie) {
    const related = movies.filter((m) => m.id !== selectedMovie.id && m.genre === selectedMovie.genre);
    return (
      <div className="px-4 py-6">
        <MoviePlayer movie={selectedMovie} relatedMovies={related} onBack={() => setSelectedMovie(null)} onPlay={handlePlay} currentUser={currentUser} inWatchlist={watchlistIds.has(selectedMovie.id)} onToggleWatchlist={toggleWatchlist} />
      </div>
    );
  }

  if (showWatchlist) {
    return (
      <div className="px-4 py-6 max-w-7xl mx-auto">
        <h2 className="text-xl font-bold mb-2 flex items-center gap-2"><Bookmark size={20} className="text-primary" /> My Watchlist</h2>
        <p className="text-base-content/50 text-sm mb-6">{watchlistMovies.length} movies saved</p>
        {watchlistMovies.length === 0 ? (
          <div className="text-center py-20">
            <Bookmark size={48} className="mx-auto opacity-20 mb-4" />
            <p className="text-base-content/50">Your watchlist is empty</p>
            <p className="text-base-content/40 text-sm mt-1">Browse movies and click the bookmark icon to add them</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {watchlistMovies.map((m) => <MovieCard key={m.id} movie={m} onPlay={handlePlay} inWatchlist={true} onToggleWatchlist={toggleWatchlist} />)}
          </div>
        )}
        <Footer />
      </div>
    );
  }

  if (searchQuery) {
    return (
      <div className="px-4 py-6 max-w-7xl mx-auto">
        <h2 className="text-lg font-bold mb-4">Search results for &quot;{searchQuery}&quot;<span className="text-base-content/50 text-sm font-normal ml-2">({filteredMovies.length} found)</span></h2>
        {filteredMovies.length === 0 ? (
          <div className="text-center py-20 text-base-content/50">
            <Film size={48} className="mx-auto opacity-20 mb-4" />
            <p className="text-lg">No movies found</p><p className="text-sm mt-1">Try a different search term</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {filteredMovies.map((m) => <MovieCard key={m.id} movie={m} onPlay={handlePlay} inWatchlist={watchlistIds.has(m.id)} onToggleWatchlist={toggleWatchlist} />)}
          </div>
        )}
        <Footer />
      </div>
    );
  }

  const activeGenres = GENRES.filter((g) => movies.some((m) => m.genre === g));

  return (
    <div className="max-w-7xl mx-auto">
      {featuredMovies.length > 0 && !selectedGenre && (
        <div className="px-4 pt-6">
          <MovieCard movie={featuredMovies[Math.floor(Date.now() / 60000) % featuredMovies.length]} onPlay={handlePlay} variant="featured" inWatchlist={watchlistIds.has(featuredMovies[Math.floor(Date.now() / 60000) % featuredMovies.length].id)} onToggleWatchlist={toggleWatchlist} />
        </div>
      )}
      <AdBanner size="leaderboard" />
      <div className="px-4 mt-2">
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-thin">
          <button className={`btn btn-sm shrink-0 ${!selectedGenre ? 'btn-primary' : 'btn-ghost bg-base-200'}`} onClick={() => setSelectedGenre('')}>All</button>
          {activeGenres.map((g) => (
            <button key={g} className={`btn btn-sm shrink-0 ${selectedGenre === g ? 'btn-primary' : 'btn-ghost bg-base-200'}`} onClick={() => setSelectedGenre(g)}>{g}</button>
          ))}
        </div>
      </div>
      {selectedGenre && (
        <div className="px-4 py-6">
          <h2 className="text-lg font-bold mb-4 flex items-center gap-2">{selectedGenre} Movies<span className="text-base-content/50 text-sm font-normal">({filteredMovies.length})</span></h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {filteredMovies.map((m) => <MovieCard key={m.id} movie={m} onPlay={handlePlay} inWatchlist={watchlistIds.has(m.id)} onToggleWatchlist={toggleWatchlist} />)}
          </div>
        </div>
      )}
      {!selectedGenre && (
        <>
          {COLLECTIONS.map((collection) => {
            const collMovies = collection.filter(movies);
            if (collMovies.length === 0) return null;
            return (
              <section key={collection.id} className="px-4 mt-6">
                <div className="flex items-center justify-between mb-4"><h2 className="text-lg font-bold">{collection.label}</h2></div>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                  {collMovies.map((m) => <MovieCard key={m.id} movie={m} onPlay={handlePlay} inWatchlist={watchlistIds.has(m.id)} onToggleWatchlist={toggleWatchlist} />)}
                </div>
              </section>
            );
          })}
          <AdBanner size="banner" />
          <section className="px-4 mt-6">
            <h2 className="text-lg font-bold flex items-center gap-2 mb-4"><Sparkles size={20} className="text-primary" /> All Movies</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {movies.map((m) => <MovieCard key={m.id} movie={m} onPlay={handlePlay} inWatchlist={watchlistIds.has(m.id)} onToggleWatchlist={toggleWatchlist} />)}
            </div>
          </section>
        </>
      )}
      <Footer />
    </div>
  );
};
