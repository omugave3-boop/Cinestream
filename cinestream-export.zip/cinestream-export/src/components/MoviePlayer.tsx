import React, { useState, useEffect } from 'react';
import { ArrowLeft, Star, Eye, Calendar, Clock, Bookmark, BookmarkCheck, ThumbsUp } from 'lucide-react';
import { Movie, User } from '../types';
import { formatViews } from '../helpers';
import { getUserRating, setUserRating as saveUserRating } from '../store';
import { AdBanner } from './AdBanner';

interface MoviePlayerProps {
  movie: Movie;
  relatedMovies: Movie[];
  onBack: () => void;
  onPlay: (movie: Movie) => void;
  currentUser: User | null;
  inWatchlist: boolean;
  onToggleWatchlist: (movieId: number) => void;
}

export const MoviePlayer: React.FC<MoviePlayerProps> = ({ movie, relatedMovies, onBack, onPlay, currentUser, inWatchlist, onToggleWatchlist }) => {
  const [userRating, setUserRating] = useState<number>(0);
  const [hoverRating, setHoverRating] = useState<number>(0);
  const [ratingSubmitted, setRatingSubmitted] = useState(false);

  useEffect(() => {
    if (currentUser) {
      const existing = getUserRating(currentUser.id, movie.id);
      if (existing !== null) {
        setUserRating(existing);
        setRatingSubmitted(true);
      } else {
        setUserRating(0);
        setRatingSubmitted(false);
      }
    }
  }, [currentUser, movie.id]);

  const handleRate = (rating: number) => {
    if (!currentUser) return;
    setUserRating(rating);
    setRatingSubmitted(true);
    saveUserRating(currentUser.id, movie.id, rating);
  };

  return (
    <div className="max-w-6xl mx-auto">
      <button className="btn btn-ghost btn-sm mb-4" onClick={onBack}><ArrowLeft size={16} /> Back to Browse</button>
      <div className="relative aspect-video bg-base-300 rounded-2xl overflow-hidden mb-6">
        <video src={movie.video_url} controls autoPlay className="absolute inset-0 w-full h-full object-contain bg-base-300" poster={movie.thumbnail_url} />
      </div>
      <AdBanner size="leaderboard" />
      <div className="flex flex-col lg:flex-row gap-6 mt-4">
        <div className="flex-1">
          <div className="flex items-start justify-between gap-4 mb-3">
            <h1 className="text-2xl sm:text-3xl font-bold">{movie.title}</h1>
            <button className="btn btn-sm btn-ghost shrink-0" onClick={() => onToggleWatchlist(movie.id)}>
              {inWatchlist ? <BookmarkCheck size={18} className="text-primary" /> : <Bookmark size={18} />}
              {inWatchlist ? 'In My List' : 'Add to List'}
            </button>
          </div>
          <div className="flex flex-wrap items-center gap-3 mb-4 text-sm text-base-content/60">
            <span className="flex items-center gap-1"><Star size={14} className="text-warning" /> {movie.rating}/10</span>
            <span className="flex items-center gap-1"><Eye size={14} className="opacity-60" /> {formatViews(movie.views)} views</span>
            <span className="flex items-center gap-1"><Calendar size={14} className="opacity-60" /> {movie.year}</span>
            <span className="flex items-center gap-1"><Clock size={14} className="opacity-60" /> {movie.duration}</span>
            <span className="badge badge-sm bg-base-200 border-0">{movie.genre}</span>
          </div>
          <p className="text-base-content/80 leading-relaxed mb-6">{movie.description}</p>
          {currentUser && (
            <div className="card bg-base-200 p-4">
              <div className="flex items-center gap-2 mb-2">
                <ThumbsUp size={16} className="text-primary" />
                <span className="text-sm font-semibold">{ratingSubmitted ? 'Your Rating' : 'Rate this Movie'}</span>
              </div>
              <div className="flex items-center gap-1">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((num) => (
                  <button key={num} className="p-0.5" onMouseEnter={() => setHoverRating(num)} onMouseLeave={() => setHoverRating(0)} onClick={() => handleRate(num)}>
                    <Star size={20} className={`transition-colors ${num <= (hoverRating || userRating) ? 'text-warning fill-warning' : 'text-base-content/20'}`} />
                  </button>
                ))}
                {userRating > 0 && <span className="text-sm text-base-content/60 ml-2">{userRating}/10</span>}
              </div>
            </div>
          )}
        </div>
        <div className="lg:w-72 shrink-0"><AdBanner size="sidebar" /></div>
      </div>
      {relatedMovies.length > 0 && (
        <div className="mt-8">
          <h2 className="text-lg font-bold mb-4">More Like This</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {relatedMovies.slice(0, 4).map((m) => (
              <div key={m.id} className="group cursor-pointer" onClick={() => onPlay(m)}>
                <div className="relative aspect-[2/3] rounded-xl overflow-hidden mb-2">
                  <img src={m.thumbnail_url} alt={m.title} className="absolute inset-0 w-full h-full object-cover transition-transform duration-300 group-hover:scale-110" />
                </div>
                <h3 className="font-semibold text-sm truncate">{m.title}</h3>
                <p className="text-xs text-base-content/60">{m.year} · {m.genre}</p>
              </div>
            ))}
          </div>
        </div>
      )}
      <AdBanner size="banner" />
    </div>
  );
};
