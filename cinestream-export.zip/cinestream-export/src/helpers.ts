import { Movie } from './types';

export const GENRES = [
  'Action', 'Comedy', 'Drama', 'Horror', 'Sci-Fi',
  'Romance', 'Thriller', 'Animation', 'Documentary', 'Fantasy'
];

export const AVATAR_COLORS = [
  'bg-primary', 'bg-secondary', 'bg-accent', 'bg-info', 'bg-success', 'bg-warning', 'bg-error'
];

export const COLLECTIONS = [
  { id: 'trending', label: '🔥 Trending Now', filter: (m: Movie[]) => [...m].sort((a, b) => b.views - a.views).slice(0, 10) },
  { id: 'top-rated', label: '⭐ Top Rated', filter: (m: Movie[]) => [...m].sort((a, b) => b.rating - a.rating).slice(0, 10) },
  { id: 'new', label: '🆕 New Releases', filter: (m: Movie[]) => [...m].sort((a, b) => b.year - a.year).slice(0, 10) },
  { id: 'featured', label: '🎬 Featured', filter: (m: Movie[]) => m.filter(x => x.featured === 1) },
];

export const SAMPLE_MOVIES: Omit<Movie, 'id' | 'created_at'>[] = [
  {
    title: 'Cosmic Odyssey',
    description: 'A breathtaking journey through space and time as astronauts discover a mysterious signal from beyond our galaxy.',
    genre: 'Sci-Fi', year: 2025,
    thumbnail_url: 'https://images.unsplash.com/photo-1534996858221-380b92700493?w=400&h=600&fit=crop',
    video_url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    rating: 8.7, duration: '2h 15m', views: 15420, featured: 1,
  },
  {
    title: 'Midnight Thunder',
    description: 'An ex-military operative must protect a small town from a ruthless cartel in this action-packed thriller.',
    genre: 'Action', year: 2024,
    thumbnail_url: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=400&h=600&fit=crop',
    video_url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
    rating: 7.9, duration: '1h 58m', views: 23100, featured: 1,
  },
  {
    title: 'Whispers in the Wind',
    description: 'A touching love story set in the Scottish Highlands during the 1920s.',
    genre: 'Romance', year: 2025,
    thumbnail_url: 'https://images.unsplash.com/photo-1485846234645-a62644f84728?w=400&h=600&fit=crop',
    video_url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    rating: 8.2, duration: '2h 05m', views: 8930, featured: 0,
  },
  {
    title: 'The Last Laugh',
    description: 'A retired comedian makes one final comeback tour that changes everything.',
    genre: 'Comedy', year: 2024,
    thumbnail_url: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=400&h=600&fit=crop',
    video_url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    rating: 7.5, duration: '1h 42m', views: 12780, featured: 0,
  },
  {
    title: 'Shadow Protocol',
    description: 'A cyber-security expert uncovers a global conspiracy that threatens to plunge the world into chaos.',
    genre: 'Thriller', year: 2025,
    thumbnail_url: 'https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=400&h=600&fit=crop',
    video_url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
    rating: 8.1, duration: '2h 10m', views: 19540, featured: 1,
  },
  {
    title: 'Echoes of Tomorrow',
    description: "In a dystopian future, a young rebel discovers she holds the key to humanity's survival.",
    genre: 'Sci-Fi', year: 2024,
    thumbnail_url: 'https://images.unsplash.com/photo-1518676590747-1e3dcf5a1e61?w=400&h=600&fit=crop',
    video_url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4',
    rating: 8.4, duration: '2h 22m', views: 27650, featured: 1,
  },
  {
    title: 'Haunted Halls',
    description: 'A group of paranormal investigators enter an abandoned asylum with a dark history.',
    genre: 'Horror', year: 2025,
    thumbnail_url: 'https://images.unsplash.com/photo-1509281373149-e957c6296406?w=400&h=600&fit=crop',
    video_url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4',
    rating: 7.3, duration: '1h 48m', views: 9870, featured: 0,
  },
  {
    title: "Dragon's Crown",
    description: 'An epic fantasy adventure about a young blacksmith who discovers a legendary artifact.',
    genre: 'Fantasy', year: 2025,
    thumbnail_url: 'https://images.unsplash.com/photo-1535016120720-40c646be5580?w=400&h=600&fit=crop',
    video_url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4',
    rating: 8.6, duration: '2h 30m', views: 31200, featured: 1,
  },
];

export function formatViews(views: number): string {
  if (views >= 1000000) return (views / 1000000).toFixed(1) + 'M';
  if (views >= 1000) return (views / 1000).toFixed(1) + 'K';
  return views.toString();
}

export function getRandomColor(): string {
  return AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)];
}

export function simpleHash(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash).toString(36);
}
