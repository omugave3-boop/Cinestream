import { Movie, User, WatchlistItem, UserRating } from './types';
import { SAMPLE_MOVIES, simpleHash } from './helpers';

// localStorage-based data store (replaces SQL database)
const KEYS = {
  movies: 'cinestream_movies',
  users: 'cinestream_users',
  watchlist: 'cinestream_watchlist',
  ratings: 'cinestream_ratings',
  nextMovieId: 'cinestream_next_movie_id',
  nextUserId: 'cinestream_next_user_id',
  initialized: 'cinestream_initialized',
};

function load<T>(key: string, fallback: T[]): T[] {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function save<T>(key: string, data: T[]) {
  localStorage.setItem(key, JSON.stringify(data));
}

function getNextId(key: string): number {
  const current = parseInt(localStorage.getItem(key) || '1', 10);
  localStorage.setItem(key, String(current + 1));
  return current;
}

// Initialize with sample data on first run
export function initStore() {
  if (localStorage.getItem(KEYS.initialized)) return;

  const movies: Movie[] = SAMPLE_MOVIES.map((m, i) => ({
    ...m,
    id: i + 1,
    created_at: new Date().toISOString(),
  }));
  save(KEYS.movies, movies);
  localStorage.setItem(KEYS.nextMovieId, String(movies.length + 1));

  // Default admin user
  const adminUser: User = {
    id: 1,
    username: 'Admin',
    email: 'admin@cinestream.com',
    password: simpleHash('admin123'),
    role: 'admin',
    avatar_color: 'bg-secondary',
    created_at: new Date().toISOString(),
  };
  save(KEYS.users, [adminUser]);
  localStorage.setItem(KEYS.nextUserId, '2');

  save(KEYS.watchlist, []);
  save(KEYS.ratings, []);
  localStorage.setItem(KEYS.initialized, 'true');
}

// ---- Movies ----
export function getMovies(): Movie[] {
  return load<Movie>(KEYS.movies, []);
}

export function addMovie(data: Omit<Movie, 'id' | 'created_at'>): Movie {
  const movies = getMovies();
  const movie: Movie = {
    ...data,
    id: getNextId(KEYS.nextMovieId),
    created_at: new Date().toISOString(),
  };
  movies.unshift(movie);
  save(KEYS.movies, movies);
  return movie;
}

export function updateMovie(id: number, data: Omit<Movie, 'id' | 'created_at'>) {
  const movies = getMovies();
  const idx = movies.findIndex((m) => m.id === id);
  if (idx >= 0) {
    movies[idx] = { ...movies[idx], ...data };
    save(KEYS.movies, movies);
  }
}

export function deleteMovie(id: number) {
  save(KEYS.movies, getMovies().filter((m) => m.id !== id));
  save(KEYS.watchlist, getWatchlist().filter((w) => w.movie_id !== id));
  save(KEYS.ratings, getRatings().filter((r) => r.movie_id !== id));
}

export function incrementViews(id: number) {
  const movies = getMovies();
  const movie = movies.find((m) => m.id === id);
  if (movie) {
    movie.views += 1;
    save(KEYS.movies, movies);
  }
}

// ---- Users ----
export function getUsers(): User[] {
  return load<User>(KEYS.users, []);
}

export function findUser(email: string, password: string, role?: string): User | undefined {
  const hashed = simpleHash(password);
  return getUsers().find(
    (u) => u.email === email && u.password === hashed && (!role || u.role === role)
  );
}

export function findUserByEmailOrUsername(email: string, username: string): User | undefined {
  return getUsers().find((u) => u.email === email || u.username === username);
}

export function registerUser(username: string, email: string, password: string, avatarColor: string): User {
  const users = getUsers();
  const user: User = {
    id: getNextId(KEYS.nextUserId),
    username,
    email,
    password: simpleHash(password),
    role: 'user',
    avatar_color: avatarColor,
    created_at: new Date().toISOString(),
  };
  users.push(user);
  save(KEYS.users, users);
  return user;
}

export function getUserCount(): number {
  return getUsers().filter((u) => u.role === 'user').length;
}

// ---- Watchlist ----
export function getWatchlist(): WatchlistItem[] {
  return load<WatchlistItem>(KEYS.watchlist, []);
}

export function getUserWatchlist(userId: number): number[] {
  return getWatchlist().filter((w) => w.user_id === userId).map((w) => w.movie_id);
}

export function addToWatchlist(userId: number, movieId: number) {
  const list = getWatchlist();
  if (!list.find((w) => w.user_id === userId && w.movie_id === movieId)) {
    list.push({ user_id: userId, movie_id: movieId });
    save(KEYS.watchlist, list);
  }
}

export function removeFromWatchlist(userId: number, movieId: number) {
  save(
    KEYS.watchlist,
    getWatchlist().filter((w) => !(w.user_id === userId && w.movie_id === movieId))
  );
}

// ---- Ratings ----
export function getRatings(): UserRating[] {
  return load<UserRating>(KEYS.ratings, []);
}

export function getUserRating(userId: number, movieId: number): number | null {
  const r = getRatings().find((r) => r.user_id === userId && r.movie_id === movieId);
  return r ? r.rating : null;
}

export function setUserRating(userId: number, movieId: number, rating: number) {
  const ratings = getRatings();
  const idx = ratings.findIndex((r) => r.user_id === userId && r.movie_id === movieId);
  if (idx >= 0) {
    ratings[idx].rating = rating;
  } else {
    ratings.push({ user_id: userId, movie_id: movieId, rating });
  }
  save(KEYS.ratings, ratings);
}
