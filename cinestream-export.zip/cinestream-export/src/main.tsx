import React, { useState, useEffect, useCallback } from 'react';
import ReactDOM from 'react-dom/client';
import { Header } from './components/Header';
import { UserView } from './components/UserView';
import { AdminPanel } from './components/AdminPanel';
import { AuthScreen } from './components/AuthScreen';
import { Movie, AppView, User, AuthTab } from './types';
import { initStore, getMovies } from './store';
import './index.css';

const App: React.FC = () => {
  const [view, setView] = useState<AppView>('auth');
  const [authTab, setAuthTab] = useState<AuthTab>('login');
  const [movies, setMovies] = useState<Movie[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [showWatchlist, setShowWatchlist] = useState(false);

  const loadMovies = useCallback(() => {
    setMovies(getMovies());
  }, []);

  useEffect(() => {
    initStore();
    loadMovies();
    setLoading(false);
  }, [loadMovies]);

  // Hash-based routing
  useEffect(() => {
    const handleHash = () => {
      const hash = window.location.hash;
      if (hash === '#admin') {
        if (currentUser && currentUser.role === 'admin') {
          setView('admin');
        } else {
          setAuthTab('admin-login');
          setView('auth');
        }
      } else if (hash === '#user' || hash === '#browse') {
        if (currentUser) {
          setView('user');
        } else {
          setAuthTab('login');
          setView('auth');
        }
      }
    };
    handleHash();
    window.addEventListener('hashchange', handleHash);
    return () => window.removeEventListener('hashchange', handleHash);
  }, [currentUser]);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    setView('user');
    window.location.hash = '#user';
  };

  const handleAdminLogin = (user: User) => {
    setCurrentUser(user);
    setView('admin');
    window.location.hash = '#admin';
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setView('auth');
    setAuthTab('login');
    setSearchQuery('');
    setShowWatchlist(false);
    window.location.hash = '';
  };

  const handleViewChange = (newView: AppView) => {
    setView(newView);
    setShowWatchlist(false);
    window.location.hash = newView === 'admin' ? '#admin' : '#user';
    setSearchQuery('');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-base-100 flex items-center justify-center">
        <div className="text-center">
          <span className="loading loading-spinner loading-lg text-primary" />
          <p className="mt-4 text-base-content/60">Loading CineStream...</p>
        </div>
      </div>
    );
  }

  if (view === 'auth' || !currentUser) {
    return <AuthScreen onLogin={handleLogin} onAdminLogin={handleAdminLogin} initialTab={authTab} />;
  }

  return (
    <div className="min-h-screen bg-base-100">
      <Header
        currentView={view}
        onViewChange={handleViewChange}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        currentUser={currentUser}
        onLogout={handleLogout}
        onWatchlist={() => setShowWatchlist(!showWatchlist)}
        showingWatchlist={showWatchlist}
      />
      {view === 'user' ? (
        <UserView
          movies={movies}
          searchQuery={searchQuery}
          currentUser={currentUser}
          showWatchlist={showWatchlist}
          onClearWatchlist={() => setShowWatchlist(false)}
          onMoviesChange={loadMovies}
        />
      ) : (
        <AdminPanel movies={movies} onRefresh={loadMovies} currentUser={currentUser} />
      )}
    </div>
  );
};

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
